package com.lslutnfra.clase2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        // opcion 1

        Button b = (Button)findViewById(R.id.button);
        b.setText("hola desde java");

        TextView t = (TextView)findViewById(R.id.textView);
        OrejaEscuchaBoton oreja = new OrejaEscuchaBoton(t);

        b.setOnClickListener(oreja);


        // opcion 2
        /*
        Button b = (Button)findViewById(R.id.button);
        b.setOnClickListener(this);
       */
        //__________

    }

    // opcion 2
    @Override
    public void onClick(View v) {
        TextView t = (TextView)findViewById(R.id.textView);
        Log.d("oreja", "hiciste click desde activity");
        t.setText("hiciste click desde activity");
    }
    //_________
}
