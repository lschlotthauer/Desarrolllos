package com.lslutnfra.clase2;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

/**
 * Created by ernesto on 29/03/16.
 */
public class OrejaEscuchaBoton implements View.OnClickListener{

    TextView t;

    public OrejaEscuchaBoton(TextView txt)
    {
        t = txt;
    }

    @Override
    public void onClick(View v) {
        Log.d("oreja", "hiciste click papa");

        t.setText("JAAAAAAAAAAAAAAAA");

    }
}
