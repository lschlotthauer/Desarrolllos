package com.lslutnfra.miprimeraaplicacion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button b;

    // modelo
    int contador;

    // vista
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        b = (Button)findViewById(R.id.button);
        txt = (TextView)findViewById(R.id.textView);

        // opcion 1
        //MyListener o = new MyListener();
        //b.setOnClickListener(o);

        // opcion 2
        b.setOnClickListener(this);

        contador=0;


        // ejemplo carga de string
        String msg = getString(R.string.mensaje);
        TextView t3 = (TextView)findViewById(R.id.textView3);
        t3.setText(msg);
    }


    @Override
    public void onClick(View v) {
        contador++;

        txt.setText("El numero es:"+contador);

        // cambio imagen
        ImageView i = (ImageView)findViewById(R.id.imageView);

        i.setImageResource(R.mipmap.ic_launcher);



    }


    @Override
    protected void onDestroy() {
        super.onDestroy();


    }
}
