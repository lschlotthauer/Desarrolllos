package com.lslutnfra.miprimeraaplicacion;

import android.util.Log;
import android.view.View;

/**
 * Created by ernesto on 05/04/16.
 */
public class MyListener implements View.OnClickListener {

    @Override
    public void onClick(View v) {
        Log.d("listener", "me hicieron click");
    }

}
